<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Carbon;

class EmployeeSchedule extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = ['user_id', 'employee_id', 'venue_id', 'start_date', 'end_date', 'start_time', 'end_time'];
    public function venue()
    {
        return $this->belongsTo(Venue::class, 'venue_id');
    }
    public function employee()
    {
        return $this->belongsTo(User::class, 'employee_id');
    }
    /**
     * The attributes that should be cast.
     *
     * @var array
     */
   
}

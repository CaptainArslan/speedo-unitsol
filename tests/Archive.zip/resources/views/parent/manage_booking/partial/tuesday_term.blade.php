<td class="us-class-schedule">
    <?php
    if (isset($days_id)) {
        $data = array_filter($days_id, function ($item) {
            return $item == '2';
        });
        $day = $parent_term->termBaseBookingDays->whereIn('day_id', $data != [] ? $data : 0)->first();
    } else {
        $day = $parent_term->termBaseBookingDays->where('day_id', 2)->first();
    }
    
    ?>
    @if (!is_null($day))
        @forelse ($child_terms as $term)
            <?php
            $total_slot = $term->tolalSlotBooked();
            
            $total = ($total_slot / $term->no_of_student) * 100;
            // dd($total_slot,$term->no_of_student);
            $price = $term->class->price * $term->no_of_class;
            $discount = ($price * $term->discount) / 100;
            $term_price = $price - $discount;
            // dd($student_id);
            
            $booked_term =
                $student_id != []
                    ? App\Models\StudentTerm::where('term_id', $term->id)
                        ->where('type', 'term')
                        ->whereIn('student_id', $student_id)
                        ->first()
                    : null;
            $term_check = false;
            // dd($assessment_requests);
            foreach ($carts as $cart) {
                if ($cart->id == $term->id && ($cart->options->type = 'term')) {
                    // if ($cart->id == $term->id && $cart->options->student_id == request()->q && ($cart->options->type = 'term')) {
                    $term_check = true;
                }
            }
            ?>
            @if ($term->timing)
                <div class="us-class-list" style="border: 1px solid {{ $term?->class->color }}!important;"
                    data-dismiss="modal" data-toggle="modal" data-target="#displayClassDetail{{ $term->id }}">
                    <span class="us-clss-timing">
                        {{ date('h:i A', strtotime($term->timing->start_time)) . ' - ' . date('h:i A', strtotime($term->timing->end_time)) }}</span>
                </div>
            @else
                <div class="us-class-list no-class">
                    <span class="us-clss-timing">No Class Available</span>
                </div>
            @endif
            <div class="modal" id="displayClassDetail{{ $term->id }}">
                <div class="modal-dialog" role="document">
                    <div class="modal-content us-model-content">
                        <div class="modal-body" style="padding: 10;">
                            <div class="nk-modal">

                                <div class="row">
                                    <div class="col-4">
                                        @if ($term->venue?->image)
                                            <img src="{{ $venue_image_url . '/' . $term->venue->image }}"
                                                style="border-radius: 10px;height:300px !important; width: 100%;" />
                                        @else
                                            <img src="{{ asset('parent-assets/images/empty-venue.jpeg') }}"
                                                style="border-radius: 10px;" />
                                        @endif
                                    </div>

                                    <div class="col-5 text-justify mt-5">
                                        <h4 style="color: #1e1e1e;">
                                            {{ $term->name }}</h4>
                                        <p>{{ ' ' . date('F d, Y', strtotime($term->start_date)) . ' - ' . date('F d, Y', strtotime($term->end_date)) }}
                                        </p>

                                        <p class="us-class-data">
                                            <strong>Class:</strong>
                                            {{ $term->class->name }}
                                        </p>

                                        <p class="us-class-data">
                                            <strong>Venue:</strong>
                                            {{ $term->venue->name }}
                                        </p>

                                        <p class="us-class-data">
                                            <strong>Lessons:</strong>
                                            {{ $term->no_of_class }}
                                            |
                                            {{ $term->time_difference }}
                                            min each
                                        </p>

                                        <p class="us-class-data">
                                            <strong>Fee:
                                                AED
                                            </strong>{{ $term->total }}
                                        </p>
                                        {{-- <p class="us-class-data">
                                    <strong>Student:
                                        
                                    {{-- </strong>{{ $student_record?->student?->name .' '.$student_record?->student?->last_name }} --}}
                                        {{-- </p> --}}
                                    </div>

                                    <div class="col-3" style="align-self: flex-end;">
                                        <div class="container">
                                            <div class="row align-items-end">
                                                <div class="col-12">
                                                    <div class="row">
                                                        @if ($student_id != [])
                                                            <div class="col-12">
                                                                <div class="us-booked-slots">
                                                                    <div class="row">
                                                                        <div class="col-3">
                                                                            <div class="user-avatar sq">
                                                                                <?php
                                                                                $student_name = $student_record?->student->name . ' ' . $student_record?->student->last_name;
                                                                                ?>
                                                                                @if ($student_record?->student?->image)
                                                                                    <img src="{{ $student_image_url . '/' . $student_record?->student->image }}"
                                                                                        alt="" class="thumb">
                                                                                @else
                                                                                    <img src="{{ asset('parent-assets/images/avatar/avt.jpeg') }}"
                                                                                        alt="" class="thumb">
                                                                                @endif

                                                                            </div>
                                                                        </div>
                                                                        <div class="col-9 mt-2">
                                                                            <h6>{{ $student_name }}</h6>

                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        @endif
                                                        <div class="col-12">
                                                            <div class="us-booked-slots">
                                                                Slots
                                                                Available
                                                                {{ $total_slot }}/{{ $term->no_of_student }}
                                                                <div class="progress">
                                                                    <div class="progress-bar progress-bar-striped @if ($total == 100) bg-success @else bg-danger @endif"
                                                                        data-progress="{{ $total }}"
                                                                        style="width: 80%;">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-12">
                                                            @if ($student_id != [])
                                                                @if (is_null($booked_term))
                                                                    @if ($total_slot < $term->no_of_student)
                                                                        <button type="button"
                                                                            @if ($term_check == false) onclick="addToCart(event,'{{ url('parent/add-to-cart-term/' . $term->id . '-' . $student_record?->student_id) }}')" @endif
                                                                            class="btn btn-lg btn-primary"
                                                                            style="background-color: #ff0000;border: none;width: 191px;display: flex;justify-content: center;float: right;margin-left: 10px;">
                                                                            @if ($term_check == true)
                                                                                Class
                                                                                added
                                                                                to
                                                                                cart
                                                                            @else
                                                                                Add
                                                                                To
                                                                                Cart
                                                                            @endif
                                                                        </button>
                                                                    @endif
                                                                @else
                                                                    <button class="btn btn-lg btn-primary"
                                                                        style="background-color: #ff0000;border: none;width: 191px;display: flex;justify-content: center;float: right;margin-left: 10px;">
                                                                        Already
                                                                        Booked
                                                                    </button>
                                                                @endif
                                                            @else
                                                                <button class="btn btn-lg btn-primary"
                                                                    style="background-color: #ff0000;border: none;width: 191px;display: flex;justify-content: center;float: right;margin-left: 10px;">First
                                                                    Select
                                                                    Student</button>
                                                            @endif
                                                        </div>
                                                        {{-- <div class="col-6">
                                                <button
                                                    type="button"
                                                    class="btn btn-lg btn-primary"
                                                    style="background-color: #E6E6E6;border: none;color: #424242;width: 120px;display: flex;justify-content: center;float: right;">Cancel</button>
                                            </div> --}}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        @empty
            <div class="us-class-list no-class">
                <span class="us-clss-timing">No Class Available</span>
        @endforelse
    @else
        <div class="us-class-list no-class">
            <span class="us-clss-timing">No Class Available</span>
        </div>
    @endif
</td>

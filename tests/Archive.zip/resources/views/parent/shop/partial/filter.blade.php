@if (!$records->isEmpty())
    <div class="row g-gs">
        @foreach ($records as $product)
            <div class="col-xxl-2 col-lg-2 col-sm-3">
                <div class="card card-bordered product-card">
                    <div class="product-thumb">
                        <a href="#">
                            <img class="card-img-top" src="{{ $image_url . '/' . $product->getFirstImage() }}"
                                alt="">
                        </a>
                        <ul class="product-badges">
                            <li><span class="badge badge-success">{{ $product->status }}</span></li>
                        </ul>

                    </div>
                    <div class="card-inner text-center">
                        <ul class="product-tags">
                            <li><a href="#">Smart Watch</a></li>
                        </ul>
                        <h5 class="product-title"><a href="#">{{ $product->name }}</a></h5>
                        <div class="product-price text-primary h5">
                            <small class="text-muted del fs-13px"></small> AED
                            {{ $product->sale_price }}

                        </div>

                        <div class="product-price text-primary h5">
                            <a href="javascript:void(0)" class="btn float-left btn-sm btn-dim btn-primary"
                                onclick="addToCart(event,'{{ url('parent/add-to-cart-product/' . $product->id) }}')">
                                <span>Add to Cart</span>
                            </a>
                        </div>

                    </div>
                </div>
            </div><!-- .col -->
        @endforeach
    </div>
@else
    <div class="nk-block-head mb-4 mt-4 border">
        <div class="nk-block-head-content">
            <h5 class="title nk-block-title m-2 center">No Record Found</h4>
                <!-- <p>All classes schedule on selected date.</p> -->
        </div>
    </div>
@endif

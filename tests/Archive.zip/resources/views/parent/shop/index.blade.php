@extends('parent.layouts.master')
@section('style')

@stop
@section('content')
    <div class="us-profile-container" style="max-width: 1440px;margin: 0 auto;">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="nk-block-head nk-block-head-sm">
                    <div class="nk-block-between">
                        <div class="nk-block-head-content">
                            <h3 class="nk-block-title page-title">Products</h3>
                        </div><!-- .nk-block-head-content -->
                        <div class="nk-block-head-content">
                            <div class="toggle-wrap nk-block-tools-toggle">
                                <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1"
                                    data-target="pageMenu"><em class="icon ni ni-more-v"></em></a>
                                <div class="toggle-expand-content" data-content="pageMenu">
                                    <ul class="nk-block-tools g-3">
                                        <li>
                                            <div class="form-control-wrap">
                                                <div class="form-icon form-icon-right">
                                                    <em class="icon ni ni-search"></em>
                                                </div>
                                                <input type="text"
                                                    onkeyup="searchProduct(event,'{{ url('parent/search-product') }}')"
                                                    class="form-control" name="name" placeholder="Search Product by Name">
                                            </div>
                                        </li>
                                        {{-- <li>
                                            <div class="drodown">
                                                <a href="#"
                                                    class="dropdown-toggle dropdown-indicator btn btn-outline-light btn-white"
                                                    data-toggle="dropdown">Status</a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <ul class="link-list-opt no-bdr">
                                                        <li><a href="#"><span>New Items</span></a></li>
                                                        <li><a href="#"><span>Featured</span></a></li>
                                                        <li><a href="#"><span>Out of Stock</span></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="nk-block-tools-opt">
                                            <a href="#" data-target="addProduct"
                                                class="toggle btn btn-icon btn-primary d-md-none"><em
                                                    class="icon ni ni-plus"></em></a>
                                            <a href="#" data-target="addProduct"
                                                class="toggle btn btn-primary d-none d-md-inline-flex"><em
                                                    class="icon ni ni-plus"></em><span>Add Product</span></a>
                                        </li> --}}
                                    </ul>
                                </div>
                            </div>
                        </div><!-- .nk-block-head-content -->
                    </div><!-- .nk-block-between -->
                </div><!-- .nk-block-head -->
                <div class="nk-block">
                    <div id="filter-product">
                        <div class="row g-gs">
                            @foreach ($products as $product)
                                <div class="col-xxl-2 col-lg-2 col-sm-3">
                                    <div class="card card-bordered product-card" style="object-fit: contain;
                                            aspect-ratio: 1/2;">
                                        <div class="product-thumb" style="height: 250px; display: flex; justify-content: center;">
                                            <a href="{{url('parent/shops/'.$product->id)}}">
                                                <img class="card-img-top"
                                                    src="{{ $image_url . '/' . $product->getFirstImage() }}" alt="" style="height: 100%; width: auto;">
                                            </a>
                                            <ul class="product-badges">
                                                <li><span class="badge badge-success">{{ $product->status }}</span></li>
                                            </ul>

                                        </div>
                                        <div class="card-inner text-center">
                                            
                                            <h5 class="product-title" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"><a href="{{url('parent/shops/'.$product->id)}}">{{ $product->name }}</a></h5>
                                            <div class="product-price text-primary h5" style="ont-size: 14px;color: #0075ff !important;margin-bottom: 20px;">
                                                <small class="text-muted del fs-13px"></small> AED
                                                {{ $product->sale_price }}

                                            </div>

                                            <div class="us-add-to-cart" style="width: 100%;float: left;display: flex;justify-content: center;margin-top: auto;flex-direction: column;">
                                                <a href="javascript:void(0)"
                                                    class="btn float-left btn-sm btn-dim btn-primary"
                                                    onclick="addToCart(event,'{{ url('parent/add-to-cart-product/' . $product->id) }}')"
                                                    style="width: 100%;background: #ff0000;color: #fff;">
                                                    <span>Add to Cart</span>
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                </div><!-- .col -->
                            @endforeach
                        </div>


                    </div>
                </div><!-- .nk-block -->

            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script src="{{ asset('parent-assets/js/us-slider.js') }}"></script>
    <script>
        $(document).ready(function() {
            if ($('#bbb_viewed_slider').length) {
                var viewedSlider = $('#bbb_viewed_slider');
                console.log(viewedSlider[0]);
                viewedSlider.owlCarousel({
                    loop: true,
                    margin: 30,
                    autoplay: true,
                    autoplayTimeout: 6000,
                    nav: false,
                    dots: false,
                    responsive: {
                        0: {
                            items: 1
                        },
                        575: {
                            items: 2
                        },
                        768: {
                            items: 3
                        },
                        991: {
                            items: 4
                        },
                        1199: {
                            items: 6
                        }
                    }
                });

                if ($('.bbb_viewed_prev').length) {
                    var prev = $('.bbb_viewed_prev');
                    prev.on('click', function() {
                        viewedSlider.trigger('prev.owl.carousel');
                    });
                }

                if ($('.bbb_viewed_next').length) {
                    var next = $('.bbb_viewed_next');
                    next.on('click', function() {
                        viewedSlider.trigger('next.owl.carousel');
                    });
                }
            }
        });
    </script>
@stop

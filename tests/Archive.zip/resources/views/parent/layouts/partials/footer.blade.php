<div class="us-footer" style="z-index: 111;width: 100% !important">
    <div style="width: 100%;float: left;color: #ffffff !important;">
        <div class="">
            <div class="us-inner-data"> <span style="font-weight: 600;">&copy; 2022 Speedo Swim Squad. </span>
                <!--Desinged & Developed by <a href="https://unitxsol.com/" target="_blank">UnitSol</a>-->
            </div>
        </div>
    </div>
</div>

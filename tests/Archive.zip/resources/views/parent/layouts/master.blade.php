<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <!-- <base href=""> -->
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description"
        content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="{{ asset('images/favicon.png') }}">
    <!-- Page Title  -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Parents Portal Dashboard | Speedo Swim Squad</title>
    <!-- StyleSheets  -->
    @include('parent.layouts.partials.style')
</head>

<body class="nk-body bg-white npc-subscription has-aside ">
    <div class="nk-app-root">
        <?php
        $user = auth()->user();
        ?>
        <!-- main @s -->
        <div class="nk-main ">
            <!-- wrap @s -->
            <div class="nk-wrap ">
                @include('parent.layouts.partials.header')
                <!-- main header @e -->
                <!-- content @s -->
                <div class="nk-content" style="width: 1440px;margin: 30px auto;">
                    {{-- <div class="container"> --}}
                    @yield('content')

                    {{-- <div class="us-profile-container">

                        <div class="nk-content-inner">

                            @if (request()->is('parent/my-bookings'))
                                <div class="nk-content-body">
                                    @yield('content')
                                    <!-- footer @s -->
                                </div>
                            @else
                                @yield('content')
                            @endif

                        </div>
                    </div> --}}
                    <!-- content @e -->
                </div>
                <!-- wrap @e -->
            </div>
            <!-- main @e -->
        </div>
        @if (request()->is('parent/shops'))
            @include('parent.layouts.partials.cart_footer')
         @endif
        @if (request()->is('parent/students'))
            @include('parent.layouts.partials.student_footer')
        @endif
        @if (request()->is('parent/profile') |
                request()->is('parent/security') |
                request()->is('parent/payment') |
                request()->is('parent/my-bookings') |
                request()->is('parent/my-privilege') |
                request()->is('parent/trainer-comments') |
                request()->is('parent/checkouts')|request()->is('parent/manage-bookings'))
                
            @include('parent.layouts.partials.footer')
        @endif
        <!-- app-root @e -->
        <!-- JavaScript -->
        @include('parent.layouts.partials.script')
        <script>
            $('#medi_info').on('change', function(e) {
                if (e.target.checked == true) {
                    $('#medical').css('display','block');
                }else{
                    $('#medical').css('display','none');
                }
                

            });
            $('#studentData').on('change', function(e) {
                if (e.target.checked == true) {

                    const user = @json($user)
                    // console.log(user.first_name)
                    $('#full-name').val(user.first_name + ' ' + user.last_name);
                    $('#dob').val(user.dob);
                    // $("input[type=date]").val(user.dob );
                    // $('#email').val(user.email);
                    $('#contact_no').val(user.contact_number);
                    $("#gender").val(user.gender).change();
                    $("#relation").val('Self').change();
                } else {
                    $('#full-name').val('');
                    $('#dob').val('');
                    // $("input[type=date]").val(user.dob );
                    // $('#email').val('');
                    $('#contact_no').val('');
                    $("#gender").val('').change();
                    $("#relation").val('').change();
                }
            })
            $('#close-cart').on('click', function(e) {
                e.preventDefault();
                $('#addNewStudent').modal('hide');
            })
        </script>

</body>

</html>

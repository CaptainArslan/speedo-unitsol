<div class="nk-add-product toggle-slide toggle-slide-right" data-content="addProduct" data-toggle-screen="any" data-toggle-overlay="true" data-toggle-body="true" data-simplebar>
    <div class="nk-block-head">
        <div class="nk-block-head-content">
            <h5 class="nk-block-title">New Product</h5>
            <div class="nk-block-des">
                <p>Add information and add new product.</p>
            </div>
        </div>
    </div><!-- .nk-block-head -->
    <div class="nk-block">
        <div class="row g-3">
            <div class="col-12">
                <div class="form-group">
                    <label class="form-label" for="product-title">Product Title</label>
                    <div class="form-control-wrap">
                        <input type="text" class="form-control" id="product-title">
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label" for="regular-price">Regular Price</label>
                    <div class="form-control-wrap">
                        <input type="text" class="form-control" id="regular-price">
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label" for="sale-price">Sale Price</label>
                    <div class="form-control-wrap">
                        <input type="text" class="form-control" id="sale-price">
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label" for="stock">Stock</label>
                    <div class="form-control-wrap">
                        <input type="text" class="form-control" id="stock">
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label" for="SKU">SKU</label>
                    <div class="form-control-wrap">
                        <input type="text" class="form-control" id="SKU">
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <label class="form-label" for="category">Category</label>
                    <div class="form-control-wrap">
                        <input type="text" class="form-control" id="category">
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <label class="form-label" for="tags">Tags</label>
                    <div class="form-control-wrap">
                        <input type="text" class="form-control" id="tags">
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="upload-zone small bg-lighter my-2">
                    <div class="dz-message">
                        <span class="dz-message-text">Drag and drop file</span>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <button class="btn btn-primary"><em class="icon ni ni-plus"></em><span>Add New</span></button>
            </div>
        </div>
    </div><!-- .nk-block -->
</div>
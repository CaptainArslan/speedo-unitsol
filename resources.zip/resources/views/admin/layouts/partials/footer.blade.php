
 <div class="nk-footer">
    <div class="container-fluid">
        <div class="nk-footer-wrap">
            <div class="nk-footer-copyright"> &copy; 2021 SwimmingPoolMS. Desinged & Developed by <a href="https://unitxsol.com/" target="_blank">UnitSol</a>
            </div>
        </div>
    </div>
</div>

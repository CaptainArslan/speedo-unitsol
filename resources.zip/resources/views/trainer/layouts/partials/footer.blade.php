<div class="nk-footer">
    <div class="container wide-xl">
        <div class="nk-footer-wrap g-2">
            <div class="nk-footer-copyright"> &copy; 2022 Speedo Swim Squad. Desinged &
                Developed by <a href="https://unitxsol.com/" target="_blank">UnitSol</a>
                <div class="nk-footer-links">

                </div>
            </div>
        </div>
    </div>
    <!-- footer @e -->
</div>

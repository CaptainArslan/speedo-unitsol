<?php

namespace App\Http\Controllers\Trainer;
use App\Http\Controllers\Controller;
use App\Models\ClassAssessment;
use Illuminate\Http\Request;

class ClassAssessmentController extends Controller
{
   
    public function index()
    {
        //
    }

   
    public function create()
    {
        //
    }

    
    public function store(Request $request)
    {
        //
    }

    
    public function show($id)
    {
        //
    }

    
    public function edit($id)
    {
        //
    }

   
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ClassAssessment  $classAssessment
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

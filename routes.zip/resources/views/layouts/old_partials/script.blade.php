<script src="{{ asset('assets/js/bundle.js?ver=2.9.0') }}"></script>
<script src="{{ asset('assets/js/scripts.js?ver=2.9.0') }}"></script>
